Ashes of the Last God — حزمة تطبيق (PWA)
=========================================
المحتويات: index.html (اللعبة) • manifest.webmanifest • sw.js (يشغّلها بدون إنترنت) • icon-*.png

الطريقة ١ — تثبيت كتطبيق على أندرويد (الأسهل، بدون حاسوب تقريباً)
 1) ارفع مجلد warrior-game-app كاملاً على أي استضافة مجانية بـ HTTPS:
      • Netlify Drop: افتح app.netlify.com/drop واسحب المجلد
      • أو GitHub Pages / Cloudflare Pages / Vercel
 2) افتح الرابط في Chrome على الهاتف ← القائمة ⋮ ← «تثبيت التطبيق» (أو «إضافة إلى الشاشة الرئيسية»).
 3) يظهر باسم وأيقونة، يفتح بملء الشاشة، ويشتغل بدون إنترنت بعد أول فتح.

الطريقة ٢ — ملف APK حقيقي
 بعد ما ترفع اللعبة وتحصل على الرابط (الطريقة ١):
   • موقع PWABuilder.com ← أدخل الرابط ← Package for stores ← Android ← Download (يعطيك APK/AAB موقّع).
   • أو مواقع تحويل جاهزة: Appilix / WebIntoApp / AppsGeyser (تدخل الرابط وتنزل APK).
 ملاحظة: لازم الرابط يكون HTTPS، وملف manifest وsw.js يجب أن يبقوا بجانب index.html.

الطريقة ٣ — كمبيوتر + Android Studio (للنشر على متجر Play)
   npm i -g @bubblewrap/cli   ثم   bubblewrap init --manifest=https://رابطك/manifest.webmanifest   ثم   bubblewrap build

ملاحظات
 • التقدم والمتجر والإعدادات تُحفظ بـ localStorage داخل التطبيق نفسه. حذف بيانات التطبيق أو إلغاء تثبيته يمسحها.
 • لتحديث اللعبة: بدّل index.html وغيّر اسم CACHE داخل sw.js (مثلاً ashes-v2).
 • فتح index.html مباشرة من ملفات الهاتف (file://) تشتغل اللعبة، لكن ما تتثبت كتطبيق ولا تعمل بدون إنترنت.
